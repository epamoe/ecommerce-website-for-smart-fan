(function($) {
    "use strict"

    //date picker classic default
    $('.datepicker-default').pickadate();

})(jQuery);